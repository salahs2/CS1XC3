#include "student.h"
#include <stdbool.h>
/// Creates a course data structure
///
/// the struct holds 4 variables, a course name, a course code, a pointer to a student struct, and total number of students in the course
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

///Creating functions some functions
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


